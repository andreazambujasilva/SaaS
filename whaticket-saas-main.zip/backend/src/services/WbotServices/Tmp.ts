let banco = {};

export default { banco };